import tkinter as tk
from tkinter import scrolledtext, messagebox, Menu, filedialog, simpledialog
import re
import os
import sys

class PrismInterpreter:
    def __init__(self, root_tk, output_callback, settings_provider):
        self.root_tk = root_tk
        self.output_callback = output_callback
        self.settings_provider = settings_provider # Access IDE settings (e.g. show_comments)
        self.variables = {}
        self.functions = {}
        self.classes = {} # Stores user-defined classes
        self.key_functions = {}
        self.windows = {} # Stores active GUI windows & canvases
        self.persistent_store = {} # Simulates database store

    def log(self, text):
        self.output_callback(text + "\n")

    def get_root_tk(self):
        if self.root_tk is None:
            # Create a hidden root window for CLI GUI operations if needed
            self.root_tk = tk.Tk()
            self.root_tk.withdraw()
        return self.root_tk

    def run(self, code):
        self.variables.clear()
        self.functions.clear()
        self.classes.clear()
        self.key_functions.clear()
        self.persistent_store.clear()
        
        # Close any lingering windows from previous runs
        for w_data in self.windows.values():
            try:
                w_data["window"].destroy()
            except:
                pass
        self.windows.clear()

        lines = code.split('\n')
        self.execute_block(lines)

    def execute_block(self, lines):
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if not line or line.startswith("#"): # Skip blank lines and standalone compiler comments
                i += 1
                continue
            
            # 1. Comments: c.comment("...")
            if line.startswith("c.comment("):
                if self.settings_provider().get("show_comments", False):
                    match = re.search(r'c\.comment\((.*?)\)', line)
                    if match:
                        cmt_text = match.group(1).strip('"\'')
                        self.log(f"[Comment]: {cmt_text}")
                i += 1
                continue
            
            # 2. Class Definition: c.create.new.type((class); ("class_name")); {
            elif line.startswith("c.create.new.type("):
                match = re.search(r'c\.create\.new\.type\(\(class\);\s*\([\"\']?(.*?)[\"\']?\);\s*\{?', line)
                if match:
                    class_name = match.group(1).strip()
                    class_lines = []
                    i += 1
                    while i < len(lines):
                        next_line = lines[i]
                        if next_line.strip() == "}":
                            i += 1
                            break
                        elif next_line.startswith("     ") or next_line.startswith("\t") or next_line.startswith("  "):
                            class_lines.append(next_line.strip())
                            i += 1
                        else:
                            break
                    self.classes[class_name] = class_lines
                    self.persistent_store[class_name] = {"type": "class", "lines": class_lines}
                    self.log(f"Class Defined & Registered: '{class_name}'")
                    continue

            # 3. Variable Definition: h.func.define;[var]
            elif line.startswith("h.func.define;"):
                match = re.search(r'h\.func\.define;\[(.*?)\]', line)
                if match:
                    var_name = match.group(1)
                    self.variables[var_name] = None
            
            # 4. Variable Change: h.change;variable:[var];[val]
            elif line.startswith("h.change;variable:"):
                match = re.search(r'h\.change;variable:\[(.*?)\];\[(.*?)\]', line)
                if match:
                    var_name = match.group(1)
                    val = match.group(2)
                    try:
                        if '.' in val:
                            val = float(val)
                        else:
                            val = int(val)
                    except ValueError:
                        pass
                    self.variables[var_name] = val

            # 5. User Input Prompt: askuser.h.func.input;[var]=("Prompt?")
            elif line.startswith("askuser.h.func.input;"):
                match = re.search(r'askuser\.h\.func\.input;\[(.*?)\]=\("(.*?)"\)', line)
                if match:
                    var_name = match.group(1)
                    prompt_text = match.group(2)
                    if self.root_tk is not None and hasattr(self.root_tk, "winfo_exists"):
                        user_val = simpledialog.askstring("Prism Input", prompt_text, parent=self.root_tk)
                    else:
                        user_val = input(prompt_text)
                    
                    if user_val is not None:
                        try:
                            if '.' in user_val:
                                user_val = float(user_val)
                            else:
                                user_val = int(user_val)
                        except ValueError:
                            pass
                        self.variables[var_name] = user_val
                        self.log(f"User Input stored in [{var_name}]: {user_val}")

            # 6. Printline
            elif line.startswith("h.printline;"):
                content = line[len("h.printline;"):].strip()
                if content.startswith('"') and content.endswith('"'):
                    self.log(content[1:-1])
                elif content.startswith('[') and content.endswith(']'):
                    var_name = content[1:-1]
                    self.log(str(self.variables.get(var_name, f"Undefined variable: {var_name}")))
                elif content.startswith("get.store."):
                    match = re.search(r'get\.store\.(list|array);\s*item\("(.*?)"\)', content)
                    if match:
                        stype = match.group(1)
                        item_name = match.group(2)
                        self.log(f"[Retrieved {stype.upper()} Item]: '{item_name}'")
                    else:
                        self.log(content)
                else:
                    self.log(content)

            # 7. scan.store
            elif line.startswith("scan.store"):
                self.log("\n--- [SCAN.STORE] DATABASE DUMP ---")
                if not self.persistent_store and not self.variables and not self.classes:
                    self.log("(Store & Memory are currently empty)")
                else:
                    if self.variables:
                        self.log("Variables:")
                        for vk, vv in self.variables.items():
                            self.log(f"  [{vk}] = {vv}")
                    if self.classes:
                        self.log("Defined Classes:")
                        for ck in self.classes.keys():
                            self.log(f"  [Class] -> {ck}")
                    if self.persistent_store:
                        self.log("Persistent Store Database:")
                        for sk, sv in self.persistent_store.items():
                            self.log(f"  Stored Asset: [{sk}] -> {sv}")
                self.log("------------------------------------\n")

            # 8. GUI Window Creation: display.h.window.show; (x); (y); (z); (window_name)
            elif line.startswith("display.h.window.show;"):
                match = re.findall(r'\((.*?)\)', line)
                if len(match) >= 4:
                    width = self.get_val(match[0])
                    height = self.get_val(match[1])
                    z_val = self.get_val(match[2])
                    w_name = match[3].strip()
                    try:
                        r = self.get_root_tk()
                        win = tk.Toplevel(r)
                        win.title(w_name)
                        win.geometry(f"{width}x{height}")
                        win.configure(bg="#ffffff")
                        canvas = tk.Canvas(win, bg="#ffffff", highlightthickness=0)
                        canvas.pack(fill=tk.BOTH, expand=True)
                        win.focus_set()
                        win.focus_force()
                        self.windows[w_name] = {"window": win, "canvas": canvas, "shapes": {}, "coords": {}}
                        self.persistent_store[w_name] = {"type": "window", "object": str(w_name)}
                        self.log(f"GUI Window Created & Stored: '{w_name}' ({width}x{height})")
                    except Exception as e:
                        self.log(f"Window Error: {e}")

            # 9. GUI 2D Shape Drawing: display.window(window name); draw(...); (x); (y); (z); (shape_name)
            elif "display.window(" in line and "draw(" in line:
                match = re.search(r'display\.window\((.*?)\);\s*draw\((.*?):\s*(.*?)\);\s*\((.*?)\);\s*\((.*?)\);\s*\((.*?)\);\s*\((.*?)\)', line)
                if match:
                    w_name = match.group(1).strip()
                    stype = match.group(3).strip().lower()
                    px = self.get_val(match[4])
                    py = self.get_val(match[5])
                    pz = self.get_val(match[6])
                    shape_name = match.group(7).strip()
                    
                    if w_name not in self.windows:
                        r = self.get_root_tk()
                        win = tk.Toplevel(r)
                        win.title(w_name)
                        win.geometry("500x400")
                        win.configure(bg="#ffffff")
                        canvas = tk.Canvas(win, bg="#ffffff", highlightthickness=0)
                        canvas.pack(fill=tk.BOTH, expand=True)
                        win.focus_set()
                        win.focus_force()
                        self.windows[w_name] = {"window": win, "canvas": canvas, "shapes": {}, "coords": {}}

                    w_data = self.windows[w_name]
                    canvas = w_data["canvas"]
                    
                    size = 50 + (pz * 10)
                    item_id = None
                    if stype == "circle":
                        item_id = canvas.create_oval(px, py, px + size, py + size, fill="#0d6efd", outline="#084298", width=2, tags=shape_name)
                    elif stype == "square":
                        item_id = canvas.create_rectangle(px, py, px + size, py + size, fill="#198754", outline="#0f5132", width=2, tags=shape_name)
                    elif stype == "triangle":
                        half = size / 2
                        item_id = canvas.create_polygon(px + half, py, px, py + size, px + size, py + size, fill="#ffc107", outline="#d39e00", width=2, tags=shape_name)
                    elif stype == "rectangle":
                        item_id = canvas.create_rectangle(px, py, px + size * 1.5, py + size, fill="#dc3545", outline="#b02a37", width=2, tags=shape_name)
                    else:
                        item_id = canvas.create_rectangle(px, py, px + size, py + size, fill="#6c757d", outline="#495057", width=2, tags=shape_name)
                        
                    w_data["shapes"][shape_name] = item_id
                    w_data["coords"][shape_name] = {"x": px, "y": py, "z": pz, "size": size}
                    self.persistent_store[shape_name] = {"type": "shape", "window": w_name, "id": str(item_id)}
                    self.log(f"GUI Shape Drawn: '{shape_name}' ({stype}) on '{w_name}' at ({px}, {py})")

            # 10. 3D Shape Rendering with Naming Support: shapes.draw.h.3d.type(...); vector1; ...; endvector; ...; :("shape_name"):
            elif line.startswith("shapes.draw.h.3d.type("):
                match = re.search(r'shapes\.draw\.h\.3d\.type\((.*?)\);\s*vector1;\s*\((.*?)\);\s*\((.*?)\);\s*\((.*?)\);\s*endvector;\s*\((.*?)\);\s*\((.*?)\);\s*\((.*?)\)(?:;\s*:\((?:\"|\')?(.*?)(?:\"|\')?\):)?', line)
                if match:
                    stype = match.group(1).strip().lower()
                    v1_x = self.get_val(match.group(2))
                    v1_y = self.get_val(match.group(3))
                    v1_z = self.get_val(match.group(4))
                    v2_x = self.get_val(match.group(5))
                    v2_y = self.get_val(match.group(6))
                    v2_z = self.get_val(match.group(7))
                    shape_name_raw = match.group(8)
                    
                    shape_name = shape_name_raw.strip('"\'') if shape_name_raw else f"3d_shape_{len(self.persistent_store)}"
                    
                    w_name = "3D_Viewport"
                    if w_name not in self.windows:
                        r = self.get_root_tk()
                        win = tk.Toplevel(r)
                        win.title("Prism 3D Viewport")
                        win.geometry("650x550")
                        win.configure(bg="#1e1e1e")
                        canvas = tk.Canvas(win, bg="#1e1e1e", highlightthickness=0)
                        canvas.pack(fill=tk.BOTH, expand=True)
                        win.focus_set()
                        win.focus_force()
                        self.windows[w_name] = {"window": win, "canvas": canvas, "shapes": {}, "coords": {}}

                    w_data = self.windows[w_name]
                    canvas = w_data["canvas"]
                    
                    depth_offset = v1_z * 10
                    x1 = v1_x + depth_offset
                    y1 = v1_y + depth_offset
                    w = v2_x
                    h = v2_y
                    depth = v2_z * 15
                    
                    if stype == "cube":
                        canvas.create_rectangle(x1, y1, x1 + w, y1 + h, outline="#0dcaf0", width=2, tags=shape_name)
                        canvas.create_rectangle(x1 + depth, y1 - depth, x1 + w + depth, y1 + h - depth, outline="#6f42c1", width=2, tags=shape_name)
                        canvas.create_line(x1, y1, x1 + depth, y1 - depth, fill="#adb5bd", width=2, tags=shape_name)
                        canvas.create_line(x1 + w, y1, x1 + w + depth, y1 - depth, fill="#adb5bd", width=2, tags=shape_name)
                        canvas.create_line(x1, y1 + h, x1 + depth, y1 + h - depth, fill="#adb5bd", width=2, tags=shape_name)
                        canvas.create_line(x1 + w, y1 + h, x1 + w + depth, y1 + h - depth, fill="#adb5bd", width=2, tags=shape_name)
                    elif stype == "sphere":
                        canvas.create_oval(x1, y1, x1 + w, y1 + h, outline="#ffc107", fill="#fd7e14", width=2, tags=shape_name)
                        canvas.create_oval(x1 + (w/4), y1 + (h/4), x1 + (3*w/4), y1 + (3*h/4), outline="#ffeeba", width=1, tags=shape_name)
                    elif stype == "cylinder":
                        canvas.create_oval(x1, y1, x1 + w, y1 + 30, outline="#20c997", width=2, tags=shape_name)
                        canvas.create_rectangle(x1, y1 + 15, x1 + w, y1 + h + 15, outline="#20c997", fill="#0f5132", width=2, tags=shape_name)
                        canvas.create_oval(x1, y1 + h, x1 + w, y1 + h + 30, outline="#20c997", width=2, tags=shape_name)
                    else:
                        canvas.create_rectangle(x1, y1, x1 + w, y1 + h, outline="#d63384", width=2, tags=shape_name)
                        canvas.create_rectangle(x1 + depth, y1 - depth, x1 + w + depth, y1 + h - depth, outline="#d63384", width=2, tags=shape_name)
                        canvas.create_line(x1, y1, x1 + depth, y1 - depth, fill="#d63384", width=2, tags=shape_name)
                        canvas.create_line(x1 + w, y1, x1 + w + depth, y1 - depth, fill="#d63384", width=2, tags=shape_name)

                    w_data["shapes"][shape_name] = shape_name
                    self.persistent_store[shape_name] = {"type": "3d_shape", "window": w_name}
                    self.log(f"3D Render & Named: '{shape_name}' ({stype}) at vector ({v1_x}, {v1_y}, {v1_z})")

            # 11. Shape Position Change: h.change.shape.pos(shape_name); (x); (y); (z);
            elif line.startswith("h.change.shape.pos("):
                match = re.findall(r'\((.*?)\)', line)
                if len(match) >= 4:
                    shape_name = match[0].strip()
                    nx = self.get_val(match[1])
                    ny = self.get_val(match[2])
                    nz = self.get_val(match[3])
                    self.update_shape_position(shape_name, nx, ny, nz)

            # 12. Apply Movement Player: apply.movement.player(shape_name); (w); (a); (s); (d)
            elif line.startswith("apply.movement.player("):
                match = re.search(r'apply\.movement\.player\((.*?)\);(.*)', line)
                if match:
                    shape_name = match.group(1).strip()
                    keys_part = match.group(2)
                    keys = re.findall(r'\((.*?)\)', keys_part)
                    
                    for w_name, w_data in self.windows.items():
                        if shape_name in w_data["shapes"]:
                            win = w_data["window"]
                            win.focus_set()
                            win.focus_force()
                            for k in keys:
                                k_clean = k.strip().lower()
                                win.bind(f"<Key-{k_clean}>", lambda event, sk=shape_name, kc=k_clean: self.handle_key_event(event, sk, kc))
                                win.bind(f"<Key-{k_clean.upper()}>", lambda event, sk=shape_name, kc=k_clean: self.handle_key_event(event, sk, kc))
                                win.bind(f"<{k_clean}>", lambda event, sk=shape_name, kc=k_clean: self.handle_key_event(event, sk, kc))
                            win.bind("<Key>", lambda event, sk=shape_name: self.handle_generic_keypress(event, sk))
                            self.log(f"Movement bound for player shape '{shape_name}' with keys: {keys}")

            # 13. Define Key Function: h.define.display.key.func(key);
            elif line.startswith("h.define.display.key.func;"):
                match = re.search(r'h\.define\.display\.key\.func;\((.*?)\);', line)
                if match:
                    key_name = match.group(1).strip().lower()
                    func_lines = []
                    i += 1
                    while i < len(lines):
                        next_line = lines[i]
                        if next_line.startswith("     ") or next_line.startswith("\t") or next_line.startswith("  "):
                            func_lines.append(next_line.strip())
                            i += 1
                        else:
                            break
                    self.key_functions[key_name] = func_lines
                    continue

            # 14. Store Reference / Shape Store / Collections
            elif line.startswith("store.") or line.startswith("list.store") or line.startswith("array.store"):
                if line.startswith("store.shape("):
                    match = re.search(r'store\.shape\((.*?)\)', line)
                    if match:
                        s_name = match.group(1).strip()
                        self.persistent_store[s_name] = "shape_record"
                        self.log(f"Store Action: Successfully persisted shape reference '{s_name}'")
                elif line.startswith("store.func("):
                    match = re.search(r'store\.func\((.*?)\)', line)
                    if match:
                        f_name = match.group(1).strip()
                        if f_name in self.functions:
                            self.persistent_store[f_name] = {"type": "function", "lines": self.functions[f_name]}
                            self.log(f"Store Action: Successfully persisted function '{f_name}'")
                elif line.startswith("store."):
                    match = re.search(r'store\.[\(\[]?(.*?)[\)\]]?;?', line)
                    if match:
                        s_name = match.group(1).strip()
                        self.persistent_store[s_name] = "saved_record"
                        self.log(f"Store Action: Successfully stored reference '{s_name}'")
                elif line.startswith("list.store") or line.startswith("array.store"):
                    coll_type = "list" if "list.store" in line else "array"
                    self.persistent_store[f"collection_{len(self.persistent_store)}"] = coll_type
                    self.log(f"Store Action: Persisted in-memory {coll_type} to database store.")

            # 15. Display Text on Window: show.text.display.h; (window_name); (x); (y); (z); ("Text")
            elif line.startswith("show.text.display.h;"):
                match = re.findall(r'\((.*?)\)', line)
                if len(match) >= 5:
                    w_name = match[0].strip()
                    px = self.get_val(match[1])
                    py = self.get_val(match[2])
                    pz = self.get_val(match[3])
                    txt_raw = match[4].strip()
                    
                    if txt_raw.startswith('"') and txt_raw.endswith('"'):
                        txt_val = txt_raw[1:-1]
                    elif txt_raw.startswith('[') and txt_raw.endswith(']'):
                        txt_val = str(self.variables.get(txt_raw[1:-1], ""))
                    else:
                        txt_val = txt_raw

                    if w_name in self.windows:
                        canvas = self.windows[w_name]["canvas"]
                        canvas.create_text(px, py, text=txt_val, anchor=tk.NW, fill="#212529", font=("Segoe UI", 10))
                        self.log(f"Rendered text on canvas '{w_name}' at ({px}, {py}): '{txt_val}'")
                    else:
                        self.log(f"Error: Window '{w_name}' not found.")

            # 16. Store CRUD: Run / Execute Stored Class or Function (find.store.[name]; run)
            elif "find.store." in line and "; run" in line:
                match = re.search(r'find\.store\.[\(\[]?(.*?)[\)\]]?;\s*run', line)
                if match:
                    name = match.group(1).strip()
                    executed = False
                    if name in self.classes:
                        self.log(f"--- Executing Class '{name}' ---")
                        self.execute_block(self.classes[name])
                        executed = True
                    elif name in self.functions:
                        self.log(f"--- Executing Function '{name}' ---")
                        self.execute_block(self.functions[name])
                        executed = True
                    elif name in self.persistent_store:
                        item = self.persistent_store[name]
                        if isinstance(item, dict) and item.get("type") == "class":
                            self.log(f"--- Executing Class '{name}' ---")
                            self.execute_block(item.get("lines", []))
                            executed = True
                    
                    if not executed:
                        self.log(f"Store Error: Item '{name}' cannot be executed.")

            # 17. Store CRUD: Delete / Remove Shape, Window, or Class (find.store.[name]; del)
            elif "find.store." in line and "; del" in line:
                match = re.search(r'find\.store\.[\(\[]?(.*?)[\)\]]?;\s*del', line)
                if match:
                    name = match.group(1).strip()
                    deleted = False
                    for w_name, w_data in self.windows.items():
                        if name in w_data["shapes"] or name in w_data["canvas"].find_withtag(name):
                            w_data["canvas"].delete(name)
                            if name in w_data["shapes"]:
                                del w_data["shapes"][name]
                            if name in w_data["coords"]:
                                del w_data["coords"][name]
                            deleted = True
                    if name in self.windows:
                        self.windows[name]["window"].destroy()
                        del self.windows[name]
                        deleted = True
                    if name in self.classes:
                        del self.classes[name]
                        deleted = True
                    if name in self.persistent_store:
                        del self.persistent_store[name]
                        deleted = True
                        
                    if deleted:
                        self.log(f"Store Action: Deleted/Removed asset '{name}' from database.")
                    else:
                        self.log(f"Store Error: Item '{name}' not found.")

            # 18. Store CRUD: Edit (find.store.[name]; edit.new.name; ([new name]); ([new val]);)
            elif "find.store." in line and "; edit.new.name;" in line:
                match = re.search(r'find\.store\.[\(\[]?(.*?)[\)\]]?;\s*edit\.new\.name;\s*\((.*?)\);\s*\((.*?)\)', line)
                if match:
                    old_name = match.group(1).strip()
                    new_name = match.group(2).strip()
                    new_val = match.group(3).strip()
                    if old_name in self.persistent_store:
                        del self.persistent_store[old_name]
                    self.persistent_store[new_name] = new_val
                    self.log(f"Store Action [EDIT]: Renamed/Updated '{old_name}' -> New Record '{new_name}'")

            # 19. Store CRUD: Replace (find.store.[name]; replace.new([new_item]);)
            elif "find.store." in line and "; replace.new" in line:
                match = re.search(r'find\.store\.[\(\[]?(.*?)[\)\]]?;\s*replace\.new\((.*?)\)', line)
                if match:
                    name = match.group(1).strip()
                    new_item = match.group(2).strip()
                    self.persistent_store[name] = new_item
                    self.log(f"Store Action [REPLACE]: Target '{name}' replaced with '{new_item}'.")

            # 20. Store Retrieval: get.store.list or get.store.array (Standalone)
            elif line.startswith("get.store."):
                match = re.search(r'get\.store\.(list|array);\s*item\("(.*?)"\)', line)
                if match:
                    stype = match.group(1)
                    item_name = match.group(2)
                    self.log(f"Store Retrieval [{stype.upper()}]: Successfully fetched item '{item_name}'.")

            # 21. Function Definition: h.func.definefunc;(name);
            elif line.startswith("h.func.definefunc;"):
                match = re.search(r'h\.func\.definefunc;\((.*?)\);', line)
                if match:
                    func_name = match.group(1).strip()
                    func_lines = []
                    i += 1
                    while i < len(lines):
                        next_line = lines[i]
                        if next_line.startswith("     ") or next_line.startswith("\t") or next_line.startswith("  "):
                            func_lines.append(next_line.strip())
                            i += 1
                        else:
                            break
                    self.functions[func_name] = func_lines
                    continue

            # 22. Count-Based Loops: loop.func.times(N);
            elif line.startswith("loop.func.times("):
                match = re.search(r'loop\.func\.times\((.*?)\);', line)
                if match:
                    count = int(self.get_val(match.group(1)))
                    loop_lines = []
                    i += 1
                    while i < len(lines):
                        next_line = lines[i]
                        if next_line.startswith("     ") or next_line.startswith("\t") or next_line.startswith("  "):
                            loop_lines.append(next_line.strip())
                            i += 1
                        else:
                            break
                    for _ in range(count):
                        self.execute_block(loop_lines)
                    continue

            # 23. Function Call: c.func_name();
            elif line.startswith("c.") and line.endswith("();"):
                match = re.search(r'c\.(.*?)\(\);', line)
                if match:
                    func_name = match.group(1)
                    if func_name in self.functions:
                        self.execute_block(self.functions[func_name])
                    else:
                        self.log(f"Error: Function '{func_name}' not found.")

            # 24. Standard Math Operations (SUM, SUB, MUL, DIV)
            elif line.startswith("maths.h.") and not line.startswith("maths.h.complexfunc."):
                op = line.split(';')[0].replace("maths.h.", "")
                match = re.findall(r'\((.*?)\)', line)
                if len(match) >= 2:
                    v1 = self.get_val(match[0])
                    v2 = self.get_val(match[1])
                    try:
                        if op == "SUM": res = v1 + v2
                        elif op == "SUB": res = v1 - v2
                        elif op == "MUL": res = v1 * v2
                        elif op == "DIV": res = v1 / v2 if v2 != 0 else "Error: Division by zero"
                        else: res = f"Unknown operation {op}"
                        self.log(f"Math Result ({op}): {res}")
                    except Exception as e:
                        self.log(f"Math Error: {e}")

            # 25. Complex Math Operations
            elif line.startswith("maths.h.complexfunc."):
                match = re.search(r'maths\.h\.complexfunc\.([A-Z]+)\b', line)
                if match:
                    op = match.group(1)
                    arguments = re.findall(r'\((.*?)\)', line)
                    try:
                        if op in ("FIBONNACI", "FIBONACCI"):
                            if len(arguments) == 2:
                                starting_values = arguments[0].split(",")
                                if len(starting_values) != 2:
                                    raise ValueError("Fibonacci requires two starting numbers")
                                first, second = (self.get_val(value) for value in starting_values)
                                count = int(self.get_val(arguments[1]))
                            elif len(arguments) == 3:
                                first = self.get_val(arguments[0])
                                second = self.get_val(arguments[1])
                                count = int(self.get_val(arguments[2]))
                            else:
                                raise ValueError("Fibonacci requires two starting numbers and a term count")
                            if count < 0:
                                raise ValueError("Fibonacci term count cannot be negative")
                            sequence = []
                            for _ in range(count):
                                sequence.append(first)
                                first, second = second, first + second
                            self.log(f"Complex Math (Fibonacci, {count} terms): {sequence}")
                        elif not arguments:
                            self.log(f"Unknown complex operation: {op}")
                        elif op == "SQU":
                            val = self.get_val(arguments[0])
                            res = val ** 2
                            self.log(f"Complex Math (Square of {val}): {res}")
                        elif op == "CUB":
                            val = self.get_val(arguments[0])
                            res = val ** 3
                            self.log(f"Complex Math (Cube of {val}): {res}")
                        elif op == "SQUROOT":
                            val = self.get_val(arguments[0])
                            res = val ** 0.5
                            self.log(f"Complex Math (Square Root of {val}): {res}")
                        else:
                            self.log(f"Unknown complex operation: {op}")
                    except Exception as e:
                        self.log(f"Complex Math Error: {e}")

            i += 1

    def update_shape_position(self, shape_name, nx, ny, nz):
        for w_name, w_data in self.windows.items():
            if shape_name in w_data["shapes"]:
                canvas = w_data["canvas"]
                item_id = w_data["shapes"][shape_name]
                if shape_name in w_data["coords"]:
                    c_data = w_data["coords"][shape_name]
                    size = c_data["size"]
                    c_data["x"] = nx
                    c_data["y"] = ny
                    c_data["z"] = nz
                    canvas.coords(item_id, nx, ny, nx + size, ny + size)
                self.log(f"Shape Position Updated: '{shape_name}' -> ({nx}, {ny})")

    def handle_generic_keypress(self, event, shape_name):
        char = event.char.lower() if event.char else event.keysym.lower()
        if char in self.key_functions:
            self.handle_key_event(event, shape_name, char)
        else:
            step = 15
            for w_name, w_data in self.windows.items():
                if shape_name in w_data["shapes"] and shape_name in w_data["coords"]:
                    c = w_data["coords"][shape_name]
                    x, y, z = c["x"], c["y"], c["z"]
                    if char in ['w', 'up']: y -= step
                    elif char in ['s', 'down']: y += step
                    elif char in ['a', 'left']: x -= step
                    elif char in ['d', 'right']: x += step
                    else: return
                    self.update_shape_position(shape_name, x, y, z)

    def handle_key_event(self, event, shape_name, key_char):
        key_char = key_char.lower()
        if key_char in self.key_functions:
            for f_line in self.key_functions[key_char]:
                if "h.change.shape.pos" in f_line:
                    for w_name, w_data in self.windows.items():
                        if shape_name in w_data["shapes"] and shape_name in w_data["coords"]:
                            c = w_data["coords"][shape_name]
                            x, y, z = c["x"], c["y"], c["z"]
                            step = 15
                            if key_char in ['w', 'up']: y -= step
                            elif key_char in ['s', 'down']: y += step
                            elif key_char in ['a', 'left']: x -= step
                            elif key_char in ['d', 'right']: x += step
                            self.update_shape_position(shape_name, x, y, z)
                else:
                    self.execute_block([f_line])
        else:
            self.handle_generic_keypress(event, shape_name)

    def get_val(self, token):
        token = token.strip()
        if token.startswith('[') and token.endswith(']'):
            return self.variables.get(token[1:-1], 0)
        try:
            if '.' in token:
                return float(token)
            return int(token)
        except ValueError:
            return token


class PrismIDE:
    def __init__(self, root):
        self.root = root
        self.root.title("Prism Language IDE - Untitled.prism")
        self.root.geometry("1080x780")
        
        # User Settings State
        self.settings = {
            "username": "User",
            "show_comments": False,
            "show_console": True,
            "theme": "light"
        }

        self.current_file_path = None

        # Top Toolbar Frame
        self.toolbar = tk.Frame(root, height=50)
        self.toolbar.pack(fill=tk.X, padx=10, pady=10)

        self.run_btn = tk.Button(self.toolbar, text="▶ Run Code", font=("Segoe UI", 10, "bold"), relief=tk.FLAT, padx=15, pady=5, command=self.run_code)
        self.run_btn.pack(side=tk.LEFT, padx=5)

        self.compile_btn = tk.Button(self.toolbar, text="⚙ Compile / Export", font=("Segoe UI", 10, "bold"), relief=tk.FLAT, padx=12, pady=5, command=self.compile_prism_file)
        self.compile_btn.pack(side=tk.LEFT, padx=5)

        self.open_btn = tk.Button(self.toolbar, text="📂 Open", font=("Segoe UI", 10), relief=tk.FLAT, padx=10, pady=5, command=self.open_file)
        self.open_btn.pack(side=tk.LEFT, padx=5)

        self.save_btn = tk.Button(self.toolbar, text="💾 Save", font=("Segoe UI", 10), relief=tk.FLAT, padx=10, pady=5, command=self.save_file)
        self.save_btn.pack(side=tk.LEFT, padx=5)

        self.clear_btn = tk.Button(self.toolbar, text="Clear Console", font=("Segoe UI", 10), relief=tk.FLAT, padx=10, pady=5, command=self.clear_console)
        self.clear_btn.pack(side=tk.LEFT, padx=5)

        self.settings_btn = tk.Button(self.toolbar, text="⚙ Options", font=("Segoe UI", 10, "bold"), relief=tk.FLAT, padx=12, pady=5, command=self.show_options)
        self.settings_btn.pack(side=tk.LEFT, padx=5)

        self.help_btn = tk.Button(self.toolbar, text="❓ Help & Syntax", font=("Segoe UI", 10, "bold"), relief=tk.FLAT, padx=12, pady=5, command=self.show_help)
        self.help_btn.pack(side=tk.LEFT, padx=5)

        # Examples Dropdown Menu Button
        self.examples_btn = tk.Menubutton(self.toolbar, text="📚 Examples ▼", font=("Segoe UI", 10, "bold"), relief=tk.FLAT, padx=12, pady=5)
        
        self.menu = Menu(self.examples_btn, tearoff=0, font=("Segoe UI", 10))
        self.examples_btn["menu"] = self.menu
        
        self.menu.add_command(label="1. Variables & Basic Math", command=lambda: self.load_example("vars_math"))
        self.menu.add_command(label="2. Custom Functions & Calls", command=lambda: self.load_example("functions"))
        self.menu.add_command(label="3. Advanced Complex Math", command=lambda: self.load_example("complex_math"))
        self.menu.add_command(label="4. GUI Display & Windows", command=lambda: self.load_example("gui_display"))
        self.menu.add_command(label="5. GUI Shapes & Canvas Store", command=lambda: self.load_example("gui_shapes"))
        self.menu.add_command(label="6. Interactive Shape Movement", command=lambda: self.load_example("interactive_movement"))
        self.menu.add_command(label="7. User Input & Loops", command=lambda: self.load_example("input_loops"))
        self.menu.add_command(label="8. 3D Shapes & scan.store", command=lambda: self.load_example("shapes_3d"))
        self.menu.add_command(label="9. Custom Classes & find.store run", command=lambda: self.load_example("classes"))
        
        self.examples_btn.pack(side=tk.LEFT, padx=5)

        # Main Layout Split (Editor & Console)
        self.paned = tk.PanedWindow(root, orient=tk.VERTICAL, sashwidth=6)
        self.paned.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        # Editor Frame
        self.editor_frame = tk.Frame(self.paned)
        self.editor_label = tk.Label(self.editor_frame, text="Code Editor (.prism)", font=("Segoe UI", 9, "bold"))
        self.editor_label.pack(anchor=tk.W, padx=5, pady=2)
        
        self.editor = scrolledtext.ScrolledText(self.editor_frame, wrap=tk.WORD, font=("Consolas", 11), bd=1, relief=tk.SOLID)
        self.editor.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.load_example("classes")
        self.paned.add(self.editor_frame, height=400)

        # Console Output Frame
        self.console_frame = tk.Frame(self.paned)
        self.console_label = tk.Label(self.console_frame, text="Console Output", font=("Segoe UI", 9, "bold"))
        self.console_label.pack(anchor=tk.W, padx=5, pady=2)

        self.console = scrolledtext.ScrolledText(self.console_frame, wrap=tk.WORD, font=("Consolas", 10), state=tk.DISABLED, bd=1, relief=tk.SOLID)
        self.console.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.paned.add(self.console_frame)

        # Initialize Interpreter
        self.interpreter = PrismInterpreter(self.root, self.write_output, lambda: self.settings)

        # Apply Default Theme
        self.apply_theme(self.settings["theme"])

    def apply_theme(self, theme_name):
        self.settings["theme"] = theme_name
        
        themes = {
            "light": {
                "root_bg": "#f5f6f8", "toolbar_bg": "#e9ecef",
                "btn_run": "#0d6efd", "btn_run_fg": "#ffffff",
                "btn_comp": "#198754", "btn_comp_fg": "#ffffff",
                "btn_std": "#495057", "btn_std_fg": "#ffffff",
                "btn_opt": "#17a2b8", "btn_opt_fg": "#ffffff",
                "btn_ex": "#6f42c1", "btn_ex_fg": "#ffffff",
                "editor_bg": "#ffffff", "editor_fg": "#111111", "editor_lbl": "#212529",
                "console_bg": "#f1f3f5", "console_fg": "#111111", "console_lbl": "#212529",
                "paned_bg": "#dee2e6"
            },
            "dark": {
                "root_bg": "#181818", "toolbar_bg": "#252526",
                "btn_run": "#0e639c", "btn_run_fg": "#ffffff",
                "btn_comp": "#2ea043", "btn_comp_fg": "#ffffff",
                "btn_std": "#3c3c3c", "btn_std_fg": "#ffffff",
                "btn_opt": "#007acc", "btn_opt_fg": "#ffffff",
                "btn_ex": "#68217a", "btn_ex_fg": "#ffffff",
                "editor_bg": "#1e1e1e", "editor_fg": "#ffffff", "editor_lbl": "#f8f9fa",
                "console_bg": "#121212", "console_fg": "#ffffff", "console_lbl": "#f8f9fa",
                "paned_bg": "#333333"
            },
            "grey": {
                "root_bg": "#343a40", "toolbar_bg": "#495057",
                "btn_run": "#198754", "btn_run_fg": "#ffffff",
                "btn_comp": "#20c997", "btn_comp_fg": "#111111",
                "btn_std": "#6c757d", "btn_std_fg": "#ffffff",
                "btn_opt": "#0dcaf0", "btn_opt_fg": "#111111",
                "btn_ex": "#ffc107", "btn_ex_fg": "#111111",
                "editor_bg": "#212529", "editor_fg": "#ffffff", "editor_lbl": "#ffffff",
                "console_bg": "#1a1d20", "console_fg": "#ffffff", "console_lbl": "#ffffff",
                "paned_bg": "#495057"
            }
        }

        t = themes.get(theme_name, themes["light"])
        
        self.root.configure(bg=t["root_bg"])
        self.toolbar.configure(bg=t["toolbar_bg"])
        self.paned.configure(bg=t["paned_bg"])

        self.run_btn.configure(bg=t["btn_run"], fg=t["btn_run_fg"])
        self.compile_btn.configure(bg=t["btn_comp"], fg=t["btn_comp_fg"])
        self.open_btn.configure(bg=t["btn_std"], fg=t["btn_std_fg"])
        self.save_btn.configure(bg=t["btn_std"], fg=t["btn_std_fg"])
        self.clear_btn.configure(bg=t["btn_std"], fg=t["btn_std_fg"])
        self.settings_btn.configure(bg=t["btn_opt"], fg=t["btn_opt_fg"])
        self.help_btn.configure(bg=t["btn_opt"], fg=t["btn_opt_fg"])
        self.examples_btn.configure(bg=t["btn_ex"], fg=t["btn_ex_fg"])

        self.editor_frame.configure(bg=t["root_bg"])
        self.editor_label.configure(bg=t["root_bg"], fg=t["editor_lbl"])
        self.editor.configure(bg=t["editor_bg"], fg=t["editor_fg"], insertbackground=t["editor_fg"])

        self.console_frame.configure(bg=t["root_bg"])
        self.console_label.configure(bg=t["root_bg"], fg=t["console_lbl"])
        self.console.configure(bg=t["console_bg"], fg=t["console_fg"])

    def show_options(self):
        opt_win = tk.Toplevel(self.root)
        opt_win.title("Prism IDE - Settings & Options")
        opt_win.geometry("400x380")
        
        bg_col = "#252526" if self.settings["theme"] == "dark" else ("#343a40" if self.settings["theme"] == "grey" else "#f5f6f8")
        fg_col = "#ffffff" if self.settings["theme"] in ["dark", "grey"] else "#111111"
        entry_bg = "#1e1e1e" if self.settings["theme"] == "dark" else ("#212529" if self.settings["theme"] == "grey" else "#ffffff")
        
        opt_win.configure(bg=bg_col)
        opt_win.grab_set()

        tk.Label(opt_win, text="IDE Preferences & Options", font=("Segoe UI", 12, "bold"), bg=bg_col, fg=fg_col).pack(pady=12)

        # Username Field
        user_frame = tk.Frame(opt_win, bg=bg_col)
        user_frame.pack(anchor=tk.W, padx=30, pady=5, fill=tk.X)
        tk.Label(user_frame, text="Username:", font=("Segoe UI", 10, "bold"), bg=bg_col, fg=fg_col).pack(side=tk.LEFT, padx=(0, 10))
        user_entry = tk.Entry(user_frame, font=("Segoe UI", 10), bg=entry_bg, fg=fg_col, insertbackground=fg_col, bd=1, relief=tk.SOLID)
        user_entry.insert(0, self.settings["username"])
        user_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Option 1 Var: Show comments in output
        comm_var = tk.BooleanVar(value=self.settings["show_comments"])
        tk.Checkbutton(opt_win, text="Option 1: Show comments in output", variable=comm_var, font=("Segoe UI", 10), bg=bg_col, fg=fg_col, selectcolor=bg_col, activebackground=bg_col, activeforeground=fg_col).pack(anchor=tk.W, padx=30, pady=5)

        # Option 2 Var: Show output tab / console
        console_var = tk.BooleanVar(value=self.settings["show_console"])
        tk.Checkbutton(opt_win, text="Option 2: Show output tab (Console)", variable=console_var, font=("Segoe UI", 10), bg=bg_col, fg=fg_col, selectcolor=bg_col, activebackground=bg_col, activeforeground=fg_col).pack(anchor=tk.W, padx=30, pady=5)

        # Option 3 Var: Preferred View Theme
        tk.Label(opt_win, text="Option 3: Preferred View Theme", font=("Segoe UI", 10, "bold"), bg=bg_col, fg=fg_col).pack(anchor=tk.W, padx=30, pady=(12, 2))
        
        theme_var = tk.StringVar(value=self.settings["theme"])
        theme_frame = tk.Frame(opt_win, bg=bg_col)
        theme_frame.pack(anchor=tk.W, padx=30, pady=5)

        for th in ["light", "dark", "grey"]:
            tk.Radiobutton(theme_frame, text=th.capitalize(), variable=theme_var, value=th, font=("Segoe UI", 10), bg=bg_col, fg=fg_col, selectcolor=bg_col, activebackground=bg_col, activeforeground=fg_col).pack(side=tk.LEFT, padx=5)

        def save_options():
            uname = user_entry.get().strip()
            self.settings["username"] = uname
            self.settings["show_comments"] = comm_var.get()
            self.settings["show_console"] = console_var.get()
            
            # Sisyphus Prime Easter Egg Trigger
            if uname == "hmm, appetizer":
                self.write_output("\nsisyphus prime reference lol\n")

            if self.settings["show_console"]:
                try:
                    self.paned.add(self.console_frame)
                except:
                    pass
            else:
                try:
                    self.paned.remove(self.console_frame)
                except:
                    pass

            self.apply_theme(theme_var.get())
            opt_win.destroy()

        save_btn = tk.Button(opt_win, text="Save & Apply", bg="#0d6efd", fg="#ffffff", font=("Segoe UI", 10, "bold"), relief=tk.FLAT, padx=15, pady=5, command=save_options)
        save_btn.pack(pady=18)

    def write_output(self, text):
        if self.settings["show_console"]:
            self.console.config(state=tk.NORMAL)
            self.console.insert(tk.END, text)
            self.console.see(tk.END)
            self.console.config(state=tk.DISABLED)

    def clear_console(self):
        self.console.config(state=tk.NORMAL)
        self.console.delete("1.0", tk.END)
        self.console.config(state=tk.DISABLED)

    def open_file(self):
        file_path = filedialog.askopenfilename(defaultextension=".prism", filetypes=[("Prism Files", "*.prism"), ("All Files", "*.*")])
        if file_path:
            try:
                with open(file_path, "r", encoding="utf-8") as file:
                    code = file.read()
                self.editor.delete("1.0", tk.END)
                self.editor.insert(tk.END, code)
                self.current_file_path = file_path
                self.root.title(f"Prism Language IDE - {file_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Could not open file:\n{e}")

    def save_file(self):
        if self.current_file_path:
            try:
                code = self.editor.get("1.0", tk.END)
                with open(self.current_file_path, "w", encoding="utf-8") as file:
                    file.write(code)
                messagebox.showinfo("Success", f"File saved successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Could not save file:\n{e}")
        else:
            self.save_as_file()

    def save_as_file(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".prism", filetypes=[("Prism Files", "*.prism"), ("All Files", "*.*")])
        if file_path:
            try:
                code = self.editor.get("1.0", tk.END)
                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(code)
                self.current_file_path = file_path
                self.root.title(f"Prism Language IDE - {file_path}")
                messagebox.showinfo("Success", f"File saved successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Could not save file:\n{e}")

    def compile_prism_file(self):
        """Compiles and exports code into a standalone runnable .prism package file."""
        file_path = filedialog.asksaveasfilename(defaultextension=".prism", filetypes=[("Prism Standalone Executable", "*.prism"), ("All Files", "*.*")])
        if file_path:
            try:
                code = self.editor.get("1.0", tk.END)
                compiled_payload = f"# Prism Standalone Package v1.0\n# Compiled by: {self.settings['username']}\n\n{code}"
                
                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(compiled_payload)
                
                self.write_output(f"\n[Compiler Success]: Compiled and exported standalone binary to:\n{file_path}\n")
                messagebox.showinfo("Compilation Success", f"Standalone .prism file compiled and saved successfully!\n\nPath: {file_path}")
            except Exception as e:
                messagebox.showerror("Compilation Error", f"Could not compile standalone file:\n{e}")

    def load_example(self, ex_key):
        self.editor.delete("1.0", tk.END)
        self.current_file_path = None
        self.root.title("Prism Language IDE - Untitled.prism")
        
        examples = {
            "vars_math": '''c.comment("Example 1: Variables and Arithmetic")

h.func.define;[score]
h.change;variable:[score];[50]

h.printline;"Initial score value:"
h.printline;[score]

maths.h.SUM; ([score]); ([score]);
maths.h.SUB; ([score]); ([10]);
maths.h.MUL; ([score]); ([2]);
''',
            "functions": '''c.comment("Example 2: Custom Functions & Store")

h.func.definefunc;(system_startup);
     h.printline;"Initializing Prism Engine..."
     h.printline;"Status: All systems online."

store.func(system_startup)
c.system_startup();
''',
            "complex_math": '''c.comment("Example 3: Advanced Complex Math")

h.func.define;[number]
h.change;variable:[number];[16]

h.printline;"Working with value: 16"
maths.h.complexfunc.SQU([number])
maths.h.complexfunc.CUB([number])
maths.h.complexfunc.SQUROOT([number])
maths.h.complexfunc.FIBONNACI; (0, 1); (10);
''',
            "gui_display": '''c.comment("Example 4: GUI Display Window")

display.h.window.show; (350); (200); (1); (MyDashboard)
store.(MyDashboard)

show.text.display.h; (MyDashboard); (30); (40); (1); ("Welcome to Prism GUI Engine!")
show.text.display.h; (MyDashboard); (30); (80); (1); ("Status: Running smoothly.")
''',
            "gui_shapes": '''c.comment("Example 5: GUI Shapes & Canvas Store")

display.window(ArtCanvas); draw(shape type: circle); (50); (50); (1); (cir1)
store.shape(cir1)

display.window(ArtCanvas); draw(shape type: square); (150); (50); (1); (sq1)
store.shape(sq1)

display.window(ArtCanvas); draw(shape type: triangle); (250); (50); (2); (tri1)
store.shape(tri1)
''',
            "interactive_movement": '''c.comment("Example 6: Interactive Shape Movement")

display.window(GameArena); draw(shape type: circle); (200); (200); (1); (player)
store.shape(player)

apply.movement.player(player); (w); (a); (s); (d)

h.define.display.key.func(w);
     h.change.shape.pos(player); (200); (180); (1);

h.define.display.key.func(s);
     h.change.shape.pos(player); (200); (220); (1);

h.define.display.key.func(a);
     h.change.shape.pos(player); (180); (200); (1);

h.define.display.key.func(d);
     h.change.shape.pos(player); (220); (200); (1);
''',
            "input_loops": '''c.comment("Example 7: User Input & Loops")

askuser.h.func.input;[username]=("Enter your name: ")
h.printline;"Hello, "
h.printline;[username]

c.comment("Looping a print statement 3 times")
loop.func.times(3);
     h.printline;"Repeating loop action..."
''',
            "shapes_3d": '''c.comment("Example 8: 3D Shapes & scan.store")

shapes.draw.h.3d.type(cube); vector1; (100); (100); (2); endvector; (120); (120); (3); :("my_cube"):
store.[my_cube]

shapes.draw.h.3d.type(sphere); vector1; (300); (100); (1); endvector; (100); (100); (2); :("my_sphere"):
store.[my_sphere]

scan.store
''',
            "classes": '''c.comment("Example 9: Custom Classes & find.store run")

c.create.new.type((class); ("PlayerEntity")); {
     h.func.define;[health]
     h.change;variable:[health];[100]
     h.printline;"PlayerEntity class initialized!"
     h.printline;[health]
}
store.[PlayerEntity]

c.comment("Execute the stored class via find.store")
find.store.[PlayerEntity]; run
'''
        }
        
        if ex_key in examples:
            self.editor.insert(tk.END, examples[ex_key])

    def show_help(self):
        help_win = tk.Toplevel(self.root)
        help_win.title("Prism Language - Master Syntax Reference Sheet")
        help_win.geometry("700x680")
        
        bg_col = "#252526" if self.settings["theme"] == "dark" else ("#343a40" if self.settings["theme"] == "grey" else "#f5f6f8")
        fg_col = "#ffffff" if self.settings["theme"] in ["dark", "grey"] else "#111111"
        txt_bg = "#1e1e1e" if self.settings["theme"] == "dark" else ("#212529" if self.settings["theme"] == "grey" else "#ffffff")

        help_win.configure(bg=bg_col)

        label = tk.Label(help_win, text="Master Syntax Reference Sheet (v3.5)", font=("Segoe UI", 12, "bold"), bg=bg_col, fg=fg_col)
        label.pack(anchor=tk.W, padx=15, pady=10)

        help_text = scrolledtext.ScrolledText(help_win, wrap=tk.WORD, font=("Consolas", 10), bg=txt_bg, fg=fg_col, bd=1, relief=tk.SOLID)
        help_text.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))

        guide_content = """--- PRISM LANGUAGE COMPLETE SYNTAX GUIDE ---

1. COMMAND LINE EXECUTION (CLI):
   Run any standalone .prism file from your terminal like this:
   > python prism_ide.py script.prism

2. STANDALONE COMPILER:
   Click "⚙ Compile / Export" on the IDE toolbar to package your script into a standalone runnable .prism file!

3. CUSTOM CLASSES & STORE EXECUTION:
   Syntax:
   c.create.new.type((class); ("class_name")); {
        (your code here, must have indentation)
   }
   store.[class_name]
   
   Execute Class:
   find.store.[class_name]; run

4. DATABASE STORE & SCANNING:
   Scan Store: scan.store (prints all stored items, classes, and variables to console)
   Store item: store.[name]
   Delete item: find.store.[name]; del

5. COMPLEX MATH:
    Fibonacci sequence: maths.h.complexfunc.FIBONNACI; (0, 1); (10);
    The last group is the number of terms to generate. The starting pair can also
    be given in separate groups, for example: (0); (1); (10).
"""
        help_text.insert(tk.END, guide_content)
        help_text.config(state=tk.DISABLED)

    def run_code(self):
        self.clear_console()
        code = self.editor.get("1.0", tk.END)
        try:
            self.interpreter.run(code)
            self.write_output("\n--- Execution Finished Successfully ---\n")
        except Exception as e:
            self.write_output(f"\n[Runtime Error]: {str(e)}\n")


if __name__ == "__main__":
    # Check if a .prism file was passed via command line arguments (CLI Mode)
    if len(sys.argv) > 1:
        target_file = sys.argv[1]
        if os.path.exists(target_file):
            with open(target_file, "r", encoding="utf-8") as f:
                file_code = f.read()
            
            # Initialize CLI Interpreter with standard print output
            cli_interpreter = PrismInterpreter(
                root_tk=None,
                output_callback=print,
                settings_provider=lambda: {"show_comments": True}
            )
            
            print(f"--- Running Prism Script: {target_file} ---")
            try:
                cli_interpreter.run(file_code)
                print("\n--- Execution Finished Successfully ---")
            except Exception as err:
                print(f"\n[Runtime Error]: {err}")
        else:
            print(f"Prism Error: File '{target_file}' not found.")
        sys.exit(0)
    
    # Otherwise, launch the Graphical IDE (GUI Mode)
    root = tk.Tk()
    app = PrismIDE(root)
    root.mainloop()