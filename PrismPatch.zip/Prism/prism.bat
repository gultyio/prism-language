@echo off
python "%~dp0prism_ide.py" %*